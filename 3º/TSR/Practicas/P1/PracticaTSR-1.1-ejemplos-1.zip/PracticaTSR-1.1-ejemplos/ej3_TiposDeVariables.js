'use strict'

let val = 5
let valS1 = val + "5";
let valS2 = val - "5";

console.log ("val = " + val)
console.log ("valS1 = " + valS1)
console.log ("valS2 = " + valS2)
