package p3;
public class Edge implements Comparable<Edge>{
    
    public Vertex getU() {

    }

    public Vertex getV() {

    }

    public int getW() {
        
    }
}
