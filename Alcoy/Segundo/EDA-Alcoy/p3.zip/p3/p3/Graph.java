package p3;
import java.util.*;
public class Graph {
    private Map<Vertex, Vertex> vertices = new HashMap<>();

    public void add(int ux, int uy, int vx, int vy, int w) {
        Vertex v1 = new Vertex(ux,uy);
        Vertex v2 = new Vertex(vx,vy);
    }

    public Set<Vertex> vertices() {

    }

    public Set<Edge> edges() {

    }
}
