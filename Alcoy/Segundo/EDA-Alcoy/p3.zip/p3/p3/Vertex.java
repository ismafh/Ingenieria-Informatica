package p3;
public class Vertex {
    
    public int x,y;

    public Vertex(int x, int y){
        this.x=x;
        this.y=y;
    }
}
